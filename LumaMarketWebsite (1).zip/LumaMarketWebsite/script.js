const products = [
 {id:1,name:"Soft Knit Throw",category:"Home",price:1299,badge:"BESTSELLER",rating:"4.9",image:"https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=700&q=80"},
 {id:2,name:"Everyday Tote",category:"Style",price:799,badge:"EVERYDAY FAVOURITE",rating:"4.8",image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=700&q=80"},
 {id:3,name:"Studio Headphones",category:"Tech",price:2499,badge:"GOOD SOUND",rating:"4.9",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"},
 {id:4,name:"Ceramic Coffee Cup",category:"Home",price:449,badge:"LITTLE JOY",rating:"4.7",image:"https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=700&q=80"},
 {id:5,name:"Minimal Wrist Watch",category:"Style",price:1899,badge:"TIMELESS",rating:"4.8",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"},
 {id:6,name:"Desk Light",category:"Home",price:1099,badge:"DESIGN PICK",rating:"4.6",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80"},
 {id:7,name:"Wireless Speaker",category:"Tech",price:1599,badge:"ON THE GO",rating:"4.8",image:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=700&q=80"},
 {id:8,name:"Everyday Sunglasses",category:"Style",price:999,badge:"SUNNY DAYS",rating:"4.7",image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80"}
];
const grid=document.querySelector("#productGrid"), search=document.querySelector("#searchInput"), sort=document.querySelector("#sortSelect");
const resultCount=document.querySelector("#resultCount"), empty=document.querySelector("#emptyState");
const cartDialog=document.querySelector("#cartDialog"), cartItems=document.querySelector("#cartItems"), cartCount=document.querySelector("#cartCount");
const cartTotal=document.querySelector("#cartTotal"), bagItemCount=document.querySelector("#bagItemCount"), toast=document.querySelector("#toast");
let selectedCategory="All", cart=[], favorites=new Set(), toastTimer;
const money=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n);
function renderProducts(){
 let list=products.filter(p=>(selectedCategory==="All"||p.category===selectedCategory)&&`${p.name} ${p.category}`.toLowerCase().includes(search.value.trim().toLowerCase()));
 if(sort.value==="low")list.sort((a,b)=>a.price-b.price);
 if(sort.value==="high")list.sort((a,b)=>b.price-a.price);
 if(sort.value==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
 grid.innerHTML=list.map(p=>`<article class="product-card">
 <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-badge">${p.badge}</span>
 <button class="heart-button ${favorites.has(p.id)?"liked":""}" data-fav="${p.id}" aria-label="${favorites.has(p.id)?"Remove":"Add"} ${p.name} ${favorites.has(p.id)?"from":"to"} favourites">♡</button></div>
 <div class="product-info"><span class="product-category">${p.category}</span><div class="product-title-line"><h3>${p.name}</h3><span class="product-price">${money(p.price)}</span></div>
 <div class="product-rating"><span>★★★★★</span> ${p.rating} · Customer favourite</div><button class="add-button" data-add="${p.id}">Add to bag&nbsp; +</button></div></article>`).join("");
 resultCount.textContent=`${list.length} thoughtful find${list.length===1?"":"s"}`;empty.hidden=list.length>0;
}
function notify(msg){toast.textContent=msg;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2100)}
function addToCart(id){let found=cart.find(x=>x.id===id);found?found.qty++:cart.push({id,qty:1});renderCart();notify("A lovely find added to your bag.");}
function renderCart(){
 let qty=cart.reduce((s,x)=>s+x.qty,0),total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
 cartCount.textContent=qty;bagItemCount.textContent=`(${qty})`;cartTotal.textContent=money(total);
 if(!cart.length){cartItems.innerHTML='<p class="demo-note">Your bag is waiting for something lovely.</p>';return;}
 cartItems.innerHTML=cart.map(x=>{let p=products.find(y=>y.id===x.id);return `<div class="cart-item"><img src="${p.image}" alt=""><div><strong>${p.name}</strong><small>${money(p.price)} each</small></div><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Remove one">−</button><span>${x.qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Add one">+</button></div></div>`}).join("");
}
grid.addEventListener("click",e=>{let add=e.target.closest("[data-add]"),fav=e.target.closest("[data-fav]");if(add)addToCart(Number(add.dataset.add));if(fav){let id=Number(fav.dataset.fav);favorites.has(id)?favorites.delete(id):favorites.add(id);renderProducts();}});
document.querySelectorAll("[data-category]").forEach(btn=>btn.addEventListener("click",()=>{selectedCategory=btn.dataset.category;document.querySelectorAll("[data-category]").forEach(b=>b.classList.toggle("active",b===btn));renderProducts();}));
document.querySelectorAll("[data-jump-category]").forEach(link=>link.addEventListener("click",()=>{selectedCategory=link.dataset.jumpCategory;document.querySelectorAll("[data-category]").forEach(b=>b.classList.toggle("active",b.dataset.category===selectedCategory));renderProducts();}));
search.addEventListener("input",renderProducts);sort.addEventListener("change",renderProducts);
document.querySelector("#searchFocus").addEventListener("click",()=>{document.querySelector("#shop").scrollIntoView({behavior:"smooth"});search.focus();});
document.querySelector("#openCart").addEventListener("click",()=>cartDialog.showModal());document.querySelector("#closeCart").addEventListener("click",()=>cartDialog.close());
cartItems.addEventListener("click",e=>{let b=e.target.closest("[data-qty]");if(!b)return;let id=Number(b.dataset.qty),item=cart.find(x=>x.id===id);if(item)item.qty+=Number(b.dataset.delta);cart=cart.filter(x=>x.qty>0);renderCart();});
document.querySelector("#clearCart").addEventListener("click",()=>{cart=[];renderCart();notify("Your bag has been cleared.");});
cartDialog.addEventListener("click",e=>{if(e.target===cartDialog)cartDialog.close();});
document.querySelector("#newsletterForm").addEventListener("submit",e=>{e.preventDefault();document.querySelector("#newsletterMessage").textContent="Thanks! This demo form is working locally.";e.target.reset();});
document.querySelector("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();